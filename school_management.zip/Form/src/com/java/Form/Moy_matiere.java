package com.java.Form;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.events.FocusAdapter;
import org.eclipse.swt.events.FocusEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

public class Moy_matiere {

	protected Shell shell;
	private Text txtLaMoyenneEst;
	private Button btnCalculer;
	private ResultSet rt;
	private Statement st;
	private String n;
	private String nn;

	/**
	 * @wbp.parser.entryPoint
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shell = new Shell();
		shell.setSize(450, 300);
		shell.setText("Moyenne de matiere");
		
		Combo combo = new Combo(shell, SWT.NONE);
		
		combo.setBounds(214, 35, 171, 28);
		Connectione p=new Connectione();
		try {
	    	
			 st = p.etablirconnection().createStatement();
			String query;
			query="select * from matiere";
			 rt = st.executeQuery(query);
			Integer v;
			while(rt.next())
			{
				 v=rt.getRow();
				  n=rt.getString(1);
				 
				  nn=rt.getString(2);
				   combo.add(v.toString()+" codm :"+n+"/label :"+nn);
				 
			}	
		
				}catch  (SQLException e2) {
					   JOptionPane.showMessageDialog(null, "aucun matiere selectionner");
				}
		
		Label lblChoisirUnMatiere = new Label(shell, SWT.NONE);
		lblChoisirUnMatiere.setBounds(46, 38, 153, 20);
		lblChoisirUnMatiere.setText("choisir une matiere");
		
		txtLaMoyenneEst = new Text(shell, SWT.BORDER);
		txtLaMoyenneEst.setText("la moyenne est:");
		txtLaMoyenneEst.setBounds(125, 83, 223, 61);
		
		btnCalculer = new Button(shell, SWT.NONE);
		btnCalculer.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				Connectione p=new Connectione();
				try {
					Statement st = p.etablirconnection().createStatement();
					String vt=combo.getItem(combo.getSelectionIndex());
					 CharSequence c = vt.subSequence(vt.indexOf(":")+1, vt.indexOf("/"));
					String query1="select (avg(ex)+avg(ds))/2 as moy from note where codm='"+c+"' ";
					ResultSet rt = st.executeQuery(query1);
					Integer v=0;
					if(rt.next())
					{
						 v=rt.getInt("moy");
						 txtLaMoyenneEst.setText("la moyene de "+nn+" est :"+v.toString());
					}
					
					
					 
					}catch  (SQLException e2) {
						System.out.println(e2.getMessage());
						   JOptionPane.showMessageDialog(null, "Erreur calcule");
					}
				
				
			}
		});
		btnCalculer.setBounds(168, 165, 90, 30);
		btnCalculer.setText("calculer");

	}
}
