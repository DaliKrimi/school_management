package com.java.Form;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.FocusAdapter;
import org.eclipse.swt.events.FocusEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

public class Modif_Matiere {

	protected Shell shell;
	private int lg=0;
private ResultSet rt;
private Statement st;
private CharSequence c;
private Text text;
private Text text_1;

	
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}
	
	
	protected void createContents() {
		shell = new Shell();
		shell.setSize(450, 300);
		shell.setText("MODIFIER_matiere");
		Combo combo = new Combo(shell, SWT.NONE);
		combo.setBounds(275, 39, 76, 28);
		combo.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {

				String v=combo.getItem(combo.getSelectionIndex());
				 c=v.subSequence(v.indexOf(":")+1, v.indexOf("/"));
				String query2;
				query2="select * from matiere where codm='"+c+"'";
				try {
					rt = st.executeQuery(query2);
					if(rt.next())
					{
					text.setText(rt.getString("codm"));
						text_1.setText(rt.getString("libelm"));
							}
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
				combo.setBounds(200, 7, 183, 28);
		
		Label lblEtudiantAModifier = new Label(shell, SWT.NONE);
		lblEtudiantAModifier.setBounds(10, 10, 135, 20);
		lblEtudiantAModifier.setText("matiere a modifier");
		
		Button btnModifier = new Button(shell, SWT.NONE);
		Connectione p=new Connectione();
	    try {
		 st = p.etablirconnection().createStatement();
			String query;
			query="select * from matiere";
			 rt = st.executeQuery(query);
			Integer i;
			while(rt.next())
			{	 i=rt.getRow();
				 String n=rt.getString(1);
				 
				 String nn=rt.getString(2);
				   combo.add(i.toString()+" codm :"+n+"/ libelle :"+nn);
				 
			}	
			}catch  (SQLException e2) {
					   JOptionPane.showMessageDialog(null, "aucun matiere selectionner");
				}
		btnModifier.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				try {
				Connectione p=new Connectione();
				Statement st = (Statement) p.etablirconnection().createStatement();
				String codm = text.getText();
				String libelle=text_1.getText();
				String query="update matiere set codm='"+codm+"',libelm='"+libelle+"' where codm='"+codm+"'";
				 st.executeUpdate(query);
				    JOptionPane.showInputDialog(this,"modification effectuez avec succ�s");
				  
				}catch  (SQLException e3) {
					System.out.println(e3.getMessage());
					   JOptionPane.showMessageDialog(null, "Erreur modification");
				}
		}
		});
				btnModifier.setBounds(54, 200, 90, 30);
		btnModifier.setText("Modifier");
		
		Label lblNom = new Label(shell, SWT.NONE);
		lblNom.setText("code matiere ");
		lblNom.setBounds(10, 70, 106, 20);
		Label lblPrenom = new Label(shell, SWT.NONE);
		lblPrenom.setText("libelle");
		lblPrenom.setBounds(24, 96, 70, 20);
		text = new Text(shell, SWT.BORDER);
		text.setBounds(137, 67, 78, 26);
		
		text_1 = new Text(shell, SWT.BORDER);
		text_1.setBounds(110, 93, 78, 26);
			}

	}

