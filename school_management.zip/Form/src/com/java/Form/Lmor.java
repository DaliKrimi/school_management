package com.java.Form;
import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.TextArea;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableModel;
public class Lmor extends JFrame {
	
	public static void main(String args[]) {
	    Lmor app = new Lmor();
	    app.init();
	    
	  }

	  public void init() {
	    this.setTitle("supp_enseignant");
	   
	    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    JPanel panel = new JPanel(new GridLayout(0,1));
	    Border border = BorderFactory.createTitledBorder("liste des enseignants");
	    panel.setBorder(border);
	    DefaultTableModel model=new DefaultTableModel();
		 JTable table = new JTable(model); 
		 
		 model.addColumn("num ");
	     model.addColumn("cin ");
	     model.addColumn("Nom");
	     model.addRow(new Object [] {"num","cin","nom"});
	    
	    Connectione p=new Connectione();
	    try {
			Statement st = p.etablirconnection().createStatement();
			String query;
			query="select * from enseignant";
			ResultSet rt = st.executeQuery(query);
			Integer v;
			while(rt.next())
			{
				 v=rt.getRow();
				 String n=rt.getString(1);
				 String nn=rt.getString(2);
				 model.addRow(new Object []{ v,n,nn});
				   
				 
			}
			Container contentPane = this.getContentPane();
		    
		    this.setSize(800, 500);
		    
			contentPane.add(table, BorderLayout.CENTER);
			table.setBounds(49, 43,400, 100);
			contentPane.add(panel);
			
			
			TextArea t = new TextArea();
			t.setBounds(341, 217, 90, 30);
			
			contentPane.add(t);
			
			this.setVisible(true);
			
			 
			 
			    
			  
			}catch  (SQLException e2) {
				   JOptionPane.showMessageDialog(null, "aucun enseignant selectionner");
			}
	    
	   
	    
	    	    
	 
	  }
	  
	  
	
}
