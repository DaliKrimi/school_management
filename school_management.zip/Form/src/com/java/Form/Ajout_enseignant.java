package com.java.Form;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

public class Ajout_enseignant {

	protected Shell shell;
	private Text text;
	private Text text_1;
	private Text text_2;
	private Text text_3;
	private Text text_4;
	private Text text_5;

	
	/**
	 * @wbp.parser.entryPoint
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shell = new Shell();
		shell.setSize(800, 500);
		shell.setText("ajout enseignant");
		
		Label lblNom = new Label(shell, SWT.NONE);
		lblNom.setBounds(49, 43, 70, 20);
		lblNom.setText("nom");
		
		Label lblPrenom = new Label(shell, SWT.NONE);
		lblPrenom.setBounds(49, 69, 70, 20);
		lblPrenom.setText("prenom");
		
		Label lblMail = new Label(shell, SWT.NONE);
		lblMail.setBounds(49, 95, 70, 20);
		lblMail.setText("mail");
		
		Label lblNumtel = new Label(shell, SWT.NONE);
		lblNumtel.setBounds(49, 121, 70, 20);
		lblNumtel.setText("num_tel");
		
		Label lblFilier = new Label(shell, SWT.NONE);
		lblFilier.setBounds(49, 147, 70, 20);
		lblFilier.setText("matier");
		
		text = new Text(shell, SWT.BORDER);
		text.setBounds(135, 40, 78, 26);
		
		text_1 = new Text(shell, SWT.BORDER);
		text_1.setBounds(135, 66, 78, 26);
		
		text_2 = new Text(shell, SWT.BORDER);
		text_2.setBounds(135, 89, 169, 26);
		
		text_3 = new Text(shell, SWT.BORDER);
		text_3.setBounds(135, 115, 123, 26);
		
		text_4 = new Text(shell, SWT.BORDER);
		text_4.setBounds(135, 141, 78, 26);
		
		Button btnAjout = new Button(shell, SWT.NONE);
		btnAjout.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				Connectione p=new Connectione();
				String nom = text.getText();
				String prenom=text_1.getText();
				String email = text_2.getText();
				int tel =Integer.parseInt( text_3.getText());
				String nomm = text_4.getText();
				String cin=text_5.getText();
				
				
				try {
				Statement st = p.etablirconnection().createStatement();
				String query;
				String query1="select codm from matiere where libelm='"+nomm+"'";
				ResultSet rt = st.executeQuery(query1);
				int v=0;
				if(rt.next())
				{
					 v=rt.getInt("codm");
					 System.out.println(v);
				}
				
				
				 query="insert INTO enseignant(cin,nom,prenom,mail,tel,codm) VALUES('"+cin+"','"+nom+"','"+prenom+"','"+email+"','"+tel+"','"+v+"')";
				 st.executeUpdate(query);
				    JOptionPane.showMessageDialog(null,"ajout effectuez avec succ�s");
				  
				}catch  (SQLException e2) {
					System.out.println(e2.getMessage());
					   JOptionPane.showMessageDialog(null, "Erreur a l'ajout");
				}
		
			
			}
		});

		
		btnAjout.setBounds(135, 238, 90, 30);
		btnAjout.setText("Ajout");
		
		Label lblCin = new Label(shell, SWT.NONE);
		lblCin.setBounds(49, 17, 70, 20);
		lblCin.setText("CIN ");
		
		text_5 = new Text(shell, SWT.BORDER);
		text_5.setBounds(135, 17, 123, 26);

	}

}
