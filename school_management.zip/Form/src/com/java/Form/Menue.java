package com.java.Form;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.FocusAdapter;
import org.eclipse.swt.events.FocusEvent;
import org.eclipse.swt.events.FocusListener;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.function.Consumer;
import org.eclipse.swt.widgets.Label;

public class Menue {

	protected Shell shell;


	/**
	 * @wbp.parser.entryPoint
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shell = new Shell();
		shell.setSize(800, 500);
		shell.setText("Menu");
		
		Button btnAjoutetudiant = new Button(shell, SWT.NONE);

		btnAjoutetudiant.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(SelectionEvent e) {
				Ajout_etudiant window = new Ajout_etudiant();
				window.open();
			}
		});
		btnAjoutetudiant.setBounds(10, 31, 148, 54);
		btnAjoutetudiant.setText("Ajout_etudiant");
		
		Button btnAjoutenseignant = new Button(shell, SWT.NONE);
		btnAjoutenseignant.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				Ajout_enseignant window=new Ajout_enseignant();
				window.open();
			}
		});
		btnAjoutenseignant.setBounds(204, 31, 157, 54);
		btnAjoutenseignant.setText("Ajout_enseignant");
		
		Button btnNewButton = new Button(shell, SWT.NONE);
		btnNewButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				try {
					Supp_etudiant window = new Supp_etudiant();
					window.open();
				} catch (Exception er) {
					er.printStackTrace();
				}
				
				
				
				
			}
		});
		btnNewButton.setBounds(10, 104, 148, 54);
		btnNewButton.setText("supp_etudiant");
		
		Button btnSuppenseignant = new Button(shell, SWT.NONE);
		btnSuppenseignant.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {

				try {
					Supp_enseignant window = new Supp_enseignant();
					window.open();
				} catch (Exception err) {
					err.printStackTrace();
				}
			
				
				
			}
		});
		btnSuppenseignant.setBounds(204, 104, 157, 54);
		btnSuppenseignant.setText("supp_enseignant");
		
		Button btnModifieretudiant = new Button(shell, SWT.NONE);
		btnModifieretudiant.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {

				try {
					Modif_etudiant window = new Modif_etudiant();
					window.open();
				} catch (Exception e3) {
					e3.printStackTrace();
				}
			
			}
		});
		btnModifieretudiant.setBounds(411, 31, 157, 54);
		btnModifieretudiant.setText("modifier_etudiant");
		
		Button btnNewButton_1 = new Button(shell, SWT.NONE);
		btnNewButton_1.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {

				try {
					Modif_enseignant window = new Modif_enseignant();
					window.open();
				} catch (Exception e5) {
					e5.printStackTrace();
				}
			
				
				
			}
		});
		btnNewButton_1.setBounds(411, 104, 157, 54);
		btnNewButton_1.setText("Modifier enseignant");
		
		Button btnMoyenneParMatiere = new Button(shell, SWT.NONE);
		btnMoyenneParMatiere.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				

				try {
					Moy_matiere window = new Moy_matiere();
					window.open();
				} catch (Exception em) {
					em.printStackTrace();
				}
			
			}
		});
		btnMoyenneParMatiere.setBounds(12, 174, 146, 54);
		btnMoyenneParMatiere.setText("moyenne par matiere");
		
		Button btnNewButton_2 = new Button(shell, SWT.NONE);
		btnNewButton_2.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {

				try {
					Affecter_note window = new Affecter_note();
					window.open();
				} catch (Exception eaj) {
					eaj.printStackTrace();
				}
			
				
			}
		});
		btnNewButton_2.setBounds(204, 174, 157, 54);
		btnNewButton_2.setText("Ajout_NOTE");
		
		Button btnNewButton_3 = new Button(shell, SWT.NONE);
		btnNewButton_3.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {

				try {
					Moy_etudiant window = new Moy_etudiant();
					window.open();
				} catch (Exception eme) {
					eme.printStackTrace();
				}
			
			}
		});
		btnNewButton_3.setBounds(411, 174, 157, 54);
		btnNewButton_3.setText("Moyenne_etudiant");
		
		Button btnAjoutmatiere = new Button(shell, SWT.NONE);
		btnAjoutmatiere.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				try {
					Ajout_matiere frame = new Ajout_matiere();
					frame.setVisible(true);
				} catch (Exception em) {
					em.printStackTrace();
				}
			}
		});
		btnAjoutmatiere.setBounds(12, 243, 146, 49);
		btnAjoutmatiere.setText("Ajout_Matiere");
		
		Button btnSuppmatiere = new Button(shell, SWT.NONE);
		btnSuppmatiere.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				try {
					Supprimer_matiere frame = new Supprimer_matiere();
					frame.setVisible(true);
				} catch (Exception es) {
					es.printStackTrace();
				}
			}
		});
		btnSuppmatiere.setBounds(12, 308, 146, 49);
		btnSuppmatiere.setText("Supp_Matiere");
		
		Button btnAjoutfiliere = new Button(shell, SWT.NONE);
		btnAjoutfiliere.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				try {
					Ajout_filier frame = new Ajout_filier();
					frame.setVisible(true);
				} catch (Exception ef) {
					ef.printStackTrace();
				}
			}
		});
		btnAjoutfiliere.setBounds(204, 244, 157, 49);
		btnAjoutfiliere.setText("Ajout_Filiere");
		
		Button btnSuppfiliere = new Button(shell, SWT.NONE);
		btnSuppfiliere.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				try {
					Supprimer_filiere frame = new Supprimer_filiere();
					frame.setVisible(true);
				} catch (Exception esf) {
					esf.printStackTrace();
				}
			}
		});
		btnSuppfiliere.setBounds(204, 308, 157, 49);
		btnSuppfiliere.setText("Supp_filiere");
		
		Button btnModifiermatiere = new Button(shell, SWT.NONE);
		btnModifiermatiere.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				try {
					Modif_Matiere window = new Modif_Matiere();
					window.open();
				} catch (Exception e5) {
					e5.printStackTrace();
				}
			}
		});
		btnModifiermatiere.setBounds(411, 243, 157, 49);
		btnModifiermatiere.setText("modifier_matiere");
		
		Button btnModifierfiliere = new Button(shell, SWT.NONE);
		btnModifierfiliere.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				try {
					Modifier_filiere frame = new Modifier_filiere();
					frame.setVisible(true);
				} catch (Exception emf) {
					emf.printStackTrace();
				}
			}
		});
		btnModifierfiliere.setBounds(411, 308, 157, 49);
		btnModifierfiliere.setText("modifier_filiere");
		
		Label lblClickerPourChoisir = new Label(shell, SWT.NONE);
		lblClickerPourChoisir.setBounds(176, 5, 362, 20);
		lblClickerPourChoisir.setText("Clicker pour choisir la fonctionnalit\u00E9:");

	}
}
