package com.java.Form;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.forms.widgets.FormToolkit;

public class Supp_enseignant {

	protected Shell shell;
	private final FormToolkit formToolkit = new FormToolkit(Display.getDefault());
private int lg=0;
	
	/**
	 * @wbp.parser.entryPoint
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shell = new Shell();
		shell.setSize(450, 300);
		shell.setText("Supp_enseignant");
		
		Button btnNewButton = new Button(shell, SWT.NONE);

		btnNewButton.setBounds(132, 116, 90, 30);
		btnNewButton.setText("Supprimer");
		
		Combo combo = new Combo(shell, SWT.NONE);
		combo.setBounds(218, 66, 204, 28);
		formToolkit.adapt(combo);
		formToolkit.paintBordersFor(combo);
		
		Label lblEtudiantASupprimer = new Label(shell, SWT.NONE);
		lblEtudiantASupprimer.setBounds(42, 69, 170, 20);
		formToolkit.adapt(lblEtudiantASupprimer, true, true);
		lblEtudiantASupprimer.setText("enseignant a supprimer");
		Connectione p=new Connectione();
	    try {
	    	
			Statement st = p.etablirconnection().createStatement();
			String query;
			query="select * from enseignant";
			ResultSet rt = st.executeQuery(query);
			Integer v;
			while(rt.next())
			{
				 v=rt.getRow();
				 String n=rt.getString(1);
				 lg=n.length();
				 String nn=rt.getString(2);
				   combo.add(v.toString()+" cin :"+n+"/nom :"+nn);
				 
			}	
			btnNewButton.addSelectionListener(new SelectionAdapter() {
				@Override
				public void widgetSelected(SelectionEvent e) {
					String v=combo.getItem(combo.getSelectionIndex());
					CharSequence c=v.subSequence(v.indexOf(":")+1, v.indexOf("/"));
					String query2;
					query2="delete from enseignant where cin='"+c+"'";
					try {
						st.executeUpdate(query2);
						JOptionPane.showInputDialog("supression effectuez avec succ�s");
					} catch (SQLException e1) {
						
						e1.printStackTrace();
						JOptionPane.showInputDialog("error");
					}
				}
			});
			
			    
			  
			}catch  (SQLException e2) {
				   JOptionPane.showMessageDialog(null, "aucun enseignant selectionner");
			}
		
		
		
		

	}
}
