package com.java.Form;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.TextArea;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Button;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Label;

public class Supp_etudiant {

	protected Shell shell;
	private final FormToolkit formToolkit = new FormToolkit(Display.getDefault());
private int lg=0;
	/**
	 * Launch the application.
	 * @param args
	 */
	

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shell = new Shell();
		shell.setSize(450, 300);
		shell.setText("Supp_etudiant");
		
		Button btnNewButton = new Button(shell, SWT.NONE);

		btnNewButton.setBounds(132, 116, 90, 30);
		btnNewButton.setText("Supprimer");
		
		Combo combo = new Combo(shell, SWT.NONE);
		combo.setBounds(218, 66, 204, 28);
		formToolkit.adapt(combo);
		formToolkit.paintBordersFor(combo);
		
		Label lblEtudiantASupprimer = new Label(shell, SWT.NONE);
		lblEtudiantASupprimer.setBounds(42, 69, 170, 20);
		formToolkit.adapt(lblEtudiantASupprimer, true, true);
		lblEtudiantASupprimer.setText("etudiant a supprimer");
		Connectione p=new Connectione();
	    try {
	    	
			Statement st = p.etablirconnection().createStatement();
			String query;
			query="select * from etudiant";
			ResultSet rt = st.executeQuery(query);
			Integer v;
			while(rt.next())
			{
				 v=rt.getRow();
				 String n=rt.getString(1);
				 lg=n.length();
				 String nn=rt.getString(2);
				   combo.add(v.toString()+" ref_scolaire :"+n+"/nom :"+nn);
				 
			}	
			btnNewButton.addSelectionListener(new SelectionAdapter() {
				@Override
				public void widgetSelected(SelectionEvent e) {
					String v=combo.getItem(combo.getSelectionIndex());
					CharSequence c=v.subSequence(v.indexOf(":")+1, v.indexOf("/"));
					String query2;
					query2="delete from etudiant where refs='"+c+"'";
					try {
						st.executeUpdate(query2);
						JOptionPane.showInputDialog(this,"supression effectuez avec succ�s");
					} catch (SQLException e1) {
						
						e1.printStackTrace();
						JOptionPane.showInputDialog(null,"error");
					}
				}
			});
			
			    
			  
			}catch  (SQLException e2) {
				   JOptionPane.showMessageDialog(null, "aucun enseignant selectionner");
			}
		
		
		
		

	}
}
