package com.java.Form;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Button;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import org.eclipse.core.runtime.FileLocator;
import org.eclipse.core.runtime.Path;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.FocusAdapter;
import org.eclipse.swt.events.FocusEvent;
import org.eclipse.wb.swt.SWTResourceManager;
import org.osgi.framework.Bundle;

import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;
import org.eclipse.swt.widgets.Composite;
import java.awt.Frame;
import java.awt.Image;

import org.eclipse.swt.awt.SWT_AWT;
import java.awt.Panel;
import java.net.MalformedURLException;
import java.net.URL;
import java.awt.BorderLayout;
import javax.swing.JRootPane;
import java.awt.Color;
import java.net.URL;

public class Acceuil {

	protected Shell shell;
	private Text text;
	private Text text_1;
	private String var;
	private String var2;
	java.sql.Statement st;
	ResultSet rt;

	/**
	 * @wbp.parser.entryPoint
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 * @param bundle 
	 */
	protected void createContents() {
		shell = new Shell();
		shell.setSize(800, 500);	
		shell.setText("LOG_IN");
		
		
		
		
	
	
	    
		
		Button btnQuitter = new Button(shell, SWT.NONE);
		btnQuitter.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDoubleClick(MouseEvent e) {
				System.exit(0);
			}
			
		});
		btnQuitter.setBounds(616, 378, 90, 30);
		btnQuitter.setText("QUITTER");
		
		text = new Text(shell, SWT.BORDER);
		text.setForeground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_FOREGROUND));
		text.setBounds(305, 101, 161, 26);
		
		Label lblUserName = new Label(shell, SWT.NONE);
		lblUserName.setBounds(178, 101, 121, 20);
		lblUserName.setText("nom d'utilisateur");
		
		Label lblAutehtification = new Label(shell, SWT.BORDER | SWT.SHADOW_IN | SWT.CENTER);
		lblAutehtification.setBounds(305, 50, 161, 30);
		lblAutehtification.setText("CONNEXION");
		
		text_1 = new Text(shell, SWT.BORDER | SWT.PASSWORD);
		text_1.setBounds(305, 146, 161, 26);
		
		Label lblModDePasse = new Label(shell, SWT.NONE);
		lblModDePasse.setBounds(178, 152, 104, 20);
		lblModDePasse.setText("mot de passe");
		
		Button btnConnect = new Button(shell, SWT.NONE);
		

		btnConnect.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {

				Connectione p=new Connectione();
				
				System.out.println(p.etablirconnection());
				var=text.getText();
				var2=text_1.getText();
				String query="SELECT * FROM admine WHERE user='"+var+"' and mdp='"+var2+"'"; 
				try {
					
					st=p.etablirconnection().createStatement();
					rt=st.executeQuery(query);
					if(rt.next()) {
						
						if(var.equalsIgnoreCase(rt.getString("user")) && var2.equalsIgnoreCase(rt.getString("mdp")))
						{
							
						System.out.println("jawek behy");
						try {
							
							Menue window = new Menue();
							window.open();
						} catch (Exception e2) {
							e2.printStackTrace();
						}
							
							
						}
						
						
					}
					 
					else 
						JOptionPane.showMessageDialog(null, "invalid mot de passe or user name");
					
				} catch (SQLException e1) {
					
					
					e1.printStackTrace();
				}
				
			
			
			}
		});
		btnConnect.setBounds(341, 217, 90, 30);
		btnConnect.setText("connect");
		
		Label lblDoubleClick = new Label(shell, SWT.NONE);
		lblDoubleClick.setBounds(474, 388, 136, 20);
		lblDoubleClick.setText("DOUBLE CLICK ICI !");
	
	}
}
