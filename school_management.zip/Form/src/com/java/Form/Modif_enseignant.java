package com.java.Form;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.FocusAdapter;
import org.eclipse.swt.events.FocusEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

public class Modif_enseignant {

	protected Shell shell;
	private int lg=0;
private ResultSet rt;
private Statement st;
private CharSequence c;
private Text text;
private Text text_1;
private Text text_2;
private Text text_3;
private Text text_4;
private Text text_5;
	
	/**
	 * @wbp.parser.entryPoint
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shell = new Shell();
		shell.setSize(450, 300);
		shell.setText("MODIFIER_ETUDIANT");
		Combo combo = new Combo(shell, SWT.NONE);
		combo.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {

				String v=combo.getItem(combo.getSelectionIndex());
				 c=v.subSequence(v.indexOf(":")+1, v.indexOf(":")+9);
				String query2;
				query2="select * from enseignant where cin='"+c+"'";
				try {
					rt = st.executeQuery(query2);
					if(rt.next())
					{
						text_5.setText(rt.getString("cin"));
						text.setText(rt.getString("nom"));
						text_1.setText(rt.getString("prenom"));
						text_2.setText(rt.getString("mail"));
						text_3.setText(rt.getString("tel"));
						int a=rt.getInt("codm");
						System.out.println(a);
						String query3="select libelm from matiere where codm='"+a+"'";
						ResultSet rr=st.executeQuery(query3);
						rr.first();
						text_4.setText(rr.getString("libelm"));
						
					}
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				
				
			
			}
		});
		combo.setBounds(200, 7, 183, 28);
		
		Label lblEtudiantAModifier = new Label(shell, SWT.NONE);
		lblEtudiantAModifier.setBounds(10, 10, 135, 20);
		lblEtudiantAModifier.setText("enseignant a modifier");
		
		Button btnModifier = new Button(shell, SWT.NONE);
		Connectione p=new Connectione();
	    try {
	    	
			 st = p.etablirconnection().createStatement();
			String query;
			query="select * from enseignant";
			 rt = st.executeQuery(query);
			Integer v;
			while(rt.next())
			{
				 v=rt.getRow();
				 String n=rt.getString(1);
				 lg=n.length();
				 String nn=rt.getString(2);
				   combo.add(v.toString()+" cin :"+n+" nom :"+nn);
				 
			}	
		
				}catch  (SQLException e2) {
					   JOptionPane.showMessageDialog(null, "aucun enseignant selectionner");
				}
		btnModifier.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				Connectione p=new Connectione();
				String nom = text.getText();
				String prenom=text_1.getText();
				String email = text_2.getText();
				int tel =Integer.parseInt( text_3.getText());
				String nomm = text_4.getText();
				String cin=text_5.getText();
				
				
				try {
				Statement st = p.etablirconnection().createStatement();
				String query;
				String query1="select codm from matiere where libelm='"+nomm+"'";
				ResultSet rt = st.executeQuery(query1);
				int v=0;
				if(rt.next())
				{
					 v=rt.getInt("codm");
					 System.out.println(v);
				}
				
				
				 query="update enseignant set cin='"+cin+"',nom='"+nom+"',prenom='"+prenom+"',mail='"+email+"',tel='"+tel+"',codm='"+v+"' where cin='"+c+"'";
				 st.executeUpdate(query);
				    JOptionPane.showInputDialog(this,"modification effectuez avec succ�s");
				  
				}catch  (SQLException e2) {
					System.out.println(e2.getMessage());
					   JOptionPane.showMessageDialog(null, "Erreur modification");
				}
		
			
			}
		});
		btnModifier.setBounds(54, 200, 90, 30);
		btnModifier.setText("Modifier");
		
		Label lblNom = new Label(shell, SWT.NONE);
		lblNom.setText("nom");
		lblNom.setBounds(24, 70, 70, 20);
		
		Label lblPrenom = new Label(shell, SWT.NONE);
		lblPrenom.setText("prenom");
		lblPrenom.setBounds(24, 96, 70, 20);
		
		Label lblMail = new Label(shell, SWT.NONE);
		lblMail.setText("mail");
		lblMail.setBounds(24, 122, 70, 20);
		
		Label lblNumtel = new Label(shell, SWT.NONE);
		lblNumtel.setText("num_tel");
		lblNumtel.setBounds(24, 148, 70, 20);
		
		Label lblFilier = new Label(shell, SWT.NONE);
		lblFilier.setText("matiere");
		lblFilier.setBounds(24, 174, 70, 20);
		
		text = new Text(shell, SWT.BORDER);
		text.setBounds(110, 67, 78, 26);
		
		text_1 = new Text(shell, SWT.BORDER);
		text_1.setBounds(110, 93, 78, 26);
		
		text_2 = new Text(shell, SWT.BORDER);
		text_2.setBounds(110, 116, 123, 26);
		
		text_3 = new Text(shell, SWT.BORDER);
		text_3.setBounds(110, 142, 123, 26);
		
		text_4 = new Text(shell, SWT.BORDER);
		text_4.setBounds(110, 168, 78, 26);
		
		Label lblCin = new Label(shell, SWT.NONE);
		lblCin.setBounds(24, 44, 70, 20);
		lblCin.setText("cin");
		
		text_5 = new Text(shell, SWT.BORDER);
		text_5.setBounds(110, 44, 111, 26);

	}
}
