package com.java.Form;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Label;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

public class Moy_etudiant {

	protected Shell shell;
	private Text txtLaMoyeneEst;
	private CharSequence c,cc;

	
	/**
	 * @wbp.parser.entryPoint
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shell = new Shell();
		shell.setSize(450, 300);
		shell.setText("Moyenne_etudiant");
		
		Label lblChoisirEtudiant = new Label(shell, SWT.NONE);
		lblChoisirEtudiant.setBounds(48, 32, 124, 20);
		lblChoisirEtudiant.setText("choisir etudiant");
		
		Combo combo = new Combo(shell, SWT.NONE);
		combo.setBounds(190, 32, 214, 28);
		Connectione p=new Connectione();
	    try {
	    	
			Statement st = p.etablirconnection().createStatement();
			String query;
			query="select * from etudiant";
			ResultSet rt = st.executeQuery(query);
			Integer v;
			while(rt.next())
			{
				 v=rt.getRow();
				 String n=rt.getString(1);
				 String nn=rt.getString(2);
				 String ff=rt.getString(6);
				   combo.add("etudiant "+v.toString()+" ref_scolaire :"+n+"/ nom :"+nn+" code_filier="+ff);
				 
			}
	    } catch (SQLException e1) {
			
			e1.printStackTrace();
			JOptionPane.showInputDialog(null,"error");
		}
		
		txtLaMoyeneEst = new Text(shell, SWT.BORDER);
		txtLaMoyeneEst.setText("la moyene est");
		txtLaMoyeneEst.setBounds(138, 97, 207, 68);
		
		Button btnCalculer = new Button(shell, SWT.NONE);
		btnCalculer.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				Connectione p=new Connectione();
				
				String v=combo.getItem(combo.getSelectionIndex());
				 c=v.subSequence(v.indexOf(":")+1, v.indexOf("/"));
				 cc=v.subSequence(v.indexOf("=")+1, v.length());
				String query1="select (avg(ex)+avg(ds))/2 as moy from note n,filier f,matiere m where f.codf='"+cc+"' and f.codf=m.codf and m.codm=n.codm and n.refs='"+c+"'";
				Statement st;
				try {
					st = p.etablirconnection().createStatement();
					ResultSet rt = st.executeQuery(query1);
					if(rt.next()) {
						txtLaMoyeneEst.setText("la moyenne est ="+rt.getString("moy"));
					}
					
				} catch (SQLException e1) {
					e1.printStackTrace(); 
				}
			}
		});
		btnCalculer.setBounds(163, 171, 90, 30);
		btnCalculer.setText("calculer");

	}
}
