package com.java.Form;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JTextField;


import com.mysql.jdbc.Statement;

import javax.swing.SpringLayout;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Ajout_filier extends JFrame {

	private JPanel contentPane;
	private JTextField codfi;
	private JLabel lblLabel;
	private JTextField libfi;
	private Statement state ;
	private Connectione conn ;

	
	public Ajout_filier() {
		
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		SpringLayout sl_contentPane = new SpringLayout();
		contentPane.setLayout(sl_contentPane);
		
		JLabel lblAjouterUneFiliere = new JLabel("Ajouter une filiere ");
		sl_contentPane.putConstraint(SpringLayout.WEST, lblAjouterUneFiliere, 15, SpringLayout.WEST, contentPane);
		sl_contentPane.putConstraint(SpringLayout.EAST, lblAjouterUneFiliere, 439, SpringLayout.WEST, contentPane);
		lblAjouterUneFiliere.setHorizontalAlignment(SwingConstants.CENTER);
		contentPane.add(lblAjouterUneFiliere);
		
		JLabel lblCodeFiliere = new JLabel("code filiere :");
		sl_contentPane.putConstraint(SpringLayout.WEST, lblCodeFiliere, 10, SpringLayout.WEST, contentPane);
		lblCodeFiliere.setVerticalAlignment(SwingConstants.TOP);
		contentPane.add(lblCodeFiliere);
		
		codfi = new JTextField();
		sl_contentPane.putConstraint(SpringLayout.NORTH, lblCodeFiliere, 6, SpringLayout.NORTH, codfi);
		sl_contentPane.putConstraint(SpringLayout.NORTH, codfi, 30, SpringLayout.NORTH, contentPane);
		sl_contentPane.putConstraint(SpringLayout.WEST, codfi, 80, SpringLayout.WEST, contentPane);
		sl_contentPane.putConstraint(SpringLayout.EAST, codfi, -276, SpringLayout.EAST, contentPane);
		sl_contentPane.putConstraint(SpringLayout.SOUTH, lblAjouterUneFiliere, -6, SpringLayout.NORTH, codfi);
		contentPane.add(codfi);
		codfi.setColumns(10);
		
		lblLabel = new JLabel("libelle :");
		sl_contentPane.putConstraint(SpringLayout.WEST, lblLabel, 0, SpringLayout.WEST, lblAjouterUneFiliere);
		contentPane.add(lblLabel);
		
		libfi = new JTextField();
		sl_contentPane.putConstraint(SpringLayout.NORTH, libfi, 24, SpringLayout.SOUTH, codfi);
		sl_contentPane.putConstraint(SpringLayout.NORTH, lblLabel, 3, SpringLayout.NORTH, libfi);
		sl_contentPane.putConstraint(SpringLayout.WEST, libfi, 0, SpringLayout.WEST, codfi);
		contentPane.add(libfi);
		libfi.setColumns(10);
		
		JButton btnAjouter = new JButton("Ajouter ");
		btnAjouter.addActionListener(new ActionListener() {
			@Override 
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

				Connectione p=new Connectione();
				
			JLabel codf;
			String code =codfi.getText();
			int codee=Integer.parseInt(code);
			JLabel libf;
			String lib =libfi.getText();
			try {
				Statement st = (Statement) p.etablirconnection().createStatement();
				st.executeUpdate("insert into filier  values ('"+codee+"','"+lib+"')");
				String lab="1"+lib;
				st.executeUpdate("insert into class values('"+lab+"','"+codee+"')");
				lab="2"+lib;
				st.executeUpdate("insert into class values('"+lab+"','"+codee+"')");
				lab="3"+lib;
				st.executeUpdate("insert into class values('"+lab+"','"+codee+"')");
				JOptionPane.showMessageDialog(null,"ajout effectuez avec succ�s");
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
				JOptionPane.showMessageDialog(null,"erreur a l'ajout");
			}
			}
		});
		sl_contentPane.putConstraint(SpringLayout.NORTH, btnAjouter, 49, SpringLayout.SOUTH, libfi);
		sl_contentPane.putConstraint(SpringLayout.WEST, btnAjouter, 163, SpringLayout.WEST, contentPane);
		contentPane.add(btnAjouter);
	}
}