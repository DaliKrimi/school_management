package com.java.Form;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Label;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.FocusAdapter;
import org.eclipse.swt.events.FocusEvent;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.widgets.Combo;

public class Ajout_etudiant {

	protected Shell shell;
	private Text text;
	private Text text_1;
	private Text text_2;
	private Text text_3;
	private Text text_5;
	private Combo combo;
	
	/**
	 * @wbp.parser.entryPoint
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shell = new Shell();
		shell.setSize(800, 500);
		shell.setText("ajout etudiant");
		
		Label lblNom = new Label(shell, SWT.NONE);
		lblNom.setBounds(49, 43, 70, 20);
		lblNom.setText("nom");
		
		Label lblPrenom = new Label(shell, SWT.NONE);
		lblPrenom.setBounds(49, 69, 70, 20);
		lblPrenom.setText("prenom");
		
		Label lblMail = new Label(shell, SWT.NONE);
		lblMail.setBounds(49, 95, 70, 20);
		lblMail.setText("mail");
		
		Label lblNumtel = new Label(shell, SWT.NONE);
		lblNumtel.setBounds(49, 121, 70, 20);
		lblNumtel.setText("num_tel");
		
		Label lblFilier = new Label(shell, SWT.NONE);
		lblFilier.setBounds(49, 147, 70, 20);
		lblFilier.setText("filier");
		
		text = new Text(shell, SWT.BORDER);
		text.setBounds(135, 40, 78, 26);
		
		text_1 = new Text(shell, SWT.BORDER);
		text_1.setBounds(135, 66, 78, 26);
		
		text_2 = new Text(shell, SWT.BORDER);
		text_2.setBounds(135, 89, 123, 26);
		
		text_3 = new Text(shell, SWT.BORDER);
		text_3.setBounds(135, 115, 123, 26);
		
		Button btnAjout = new Button(shell, SWT.NONE);
		btnAjout.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				Connectione p=new Connectione();
				String nom = text.getText();
				String prenom=text_1.getText();
				String email = text_2.getText();
				int tel =Integer.parseInt( text_3.getText());
				String v1=(String) combo.getItem(combo.getSelectionIndex());
				CharSequence c=v1.subSequence(v1.indexOf(":")+1,v1.length());
				String nomc = text_5.getText();
				String query1="select codf from filier where libelf='"+c+"'";
				
				try {
				Statement st = p.etablirconnection().createStatement();
				String query;
				ResultSet rt = st.executeQuery(query1);
				int v=0;
				
				if(rt.next())
				{
					 v=rt.getInt("codf");
				}
				
				
				String va=nomc+c;
				 query="insert INTO etudiant(nom,prenom,mail,tel,codf,refc) VALUES('"+nom+"','"+prenom+"','"+email+"','"+tel+"','"+v+"','"+va+"')";
				 st.executeUpdate(query);
				    JOptionPane.showMessageDialog(null,"ajout effectuez avec succ�s");
				  
				}catch  (SQLException e2) {
					   JOptionPane.showMessageDialog(null, "Erreur a l'ajout");
				}
		
			
			}
		});

		
		btnAjout.setBounds(135, 238, 90, 30);
		btnAjout.setText("Ajout");
		
		
		Label lblNumclass = new Label(shell, SWT.NONE);
		lblNumclass.setBounds(49, 173, 150, 20);
		lblNumclass.setText("niveau_etude");
		text_5 = new Text(shell, SWT.BORDER);
		text_5.setBounds(205, 170, 91, 26);
		
		 combo = new Combo(shell, SWT.NONE);
		combo.setBounds(135, 139, 161, 28);
		 try {
		    	Connectione p=new Connectione();
				Statement st = (Statement) p.etablirconnection().createStatement();
				String query;
				query="select * from filier";
				ResultSet rt = st.executeQuery(query);
				Integer v;
				while(rt.next())
				{
					 v=rt.getRow();
					 String n=rt.getString(1);
					 String nn=rt.getString(2);
					   combo.add(v.toString()+"code_filiere/"+n+"libelle:"+nn);
					 
				}
				}catch  (SQLException e2) {
					   JOptionPane.showMessageDialog(null, "aucune filiere  selectionner");
					
				}

	}
}
