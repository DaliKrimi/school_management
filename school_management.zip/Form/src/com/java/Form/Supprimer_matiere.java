package com.java.Form;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.eclipse.swt.custom.CCombo;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.Box;
import javax.swing.JTextField;
import javax.swing.JButton;

import com.mysql.jdbc.Statement;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JComboBox;

public class Supprimer_matiere extends JFrame {

	private JPanel contentPane;

	public Supprimer_matiere() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblSupprimerMatiere = new JLabel("Supprimer matiere ");
		lblSupprimerMatiere.setBounds(5, 5, 424, 14);
		lblSupprimerMatiere.setHorizontalAlignment(SwingConstants.CENTER);
		lblSupprimerMatiere.setToolTipText("");
		contentPane.add(lblSupprimerMatiere);
		
		JComboBox combo = new JComboBox();
		combo.setBounds(216, 46, 114, 21);
		contentPane.add(combo);
		
		JLabel lblNewLabel = new JLabel("matiere a supprimer");
		lblNewLabel.setBounds(15, 28, 140, 57);
		contentPane.add(lblNewLabel);
	
		JButton btnSupprimer = new JButton("Supprimer ");
		btnSupprimer.setBounds(119, 114, 140, 57);
		contentPane.add(btnSupprimer);
		
		Connectione p=new Connectione();
	    try {
	    	
			Statement st = (Statement) p.etablirconnection().createStatement();
			String query;
			query="select * from matiere";
			ResultSet rt = st.executeQuery(query);
			Integer v;
			while(rt.next())
			{
				 v=rt.getRow();
				 String n=rt.getString(1);
				 int lg = n.length();
				 String nn=rt.getString(2);
				   combo.addItem(v.toString()+" code matiere :"+n+"/libelle :"+nn);
				 
			}
		btnSupprimer.addActionListener(new ActionListener() {
			@Override 
			public void actionPerformed(ActionEvent e) {
				String v=(String) combo.getItemAt(combo.getSelectedIndex());
				CharSequence c=v.subSequence(v.indexOf(":")+1, v.indexOf("/"));
				String query2;
				query2="delete from matiere where codm='"+c+"'";
				try {
					st.executeUpdate(query2);
					JOptionPane.showInputDialog("supression effectuez avec succ�s");
			}
			 catch (SQLException e1) {
				
				e1.printStackTrace();
				JOptionPane.showInputDialog("error");
			}
		}
	
			}
		);
	}catch  (SQLException e2) {
		   JOptionPane.showMessageDialog(null, "aucune matiere  selectionner");
		btnSupprimer.setBounds(79, 93, 89, 23);
		contentPane.add(btnSupprimer);
	}
	}	
}