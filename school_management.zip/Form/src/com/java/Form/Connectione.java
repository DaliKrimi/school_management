package com.java.Form;

import java.sql.Connection;
import java.sql.DriverManager;

public class Connectione {
	
	private Connection con; 
	public Connectione()
	{
		try {
			Class.forName("com.mysql.jdbc.Driver");  
			con=DriverManager.getConnection("jdbc:mysql://localhost/gestione","root","");
			
			System.out.println("connection �tablie");
		
		} catch (Exception e) {
			
			e.printStackTrace();
			System.out.println("Base de donnee introuvable");
		}
	}
	public Connection etablirconnection() {
		return con;
	}
	
	}
