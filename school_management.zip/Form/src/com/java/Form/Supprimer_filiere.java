package com.java.Form;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.SpringLayout;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JComboBox;

import com.mysql.jdbc.Statement;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Supprimer_filiere extends JFrame {

	private JPanel contentPane;

	
	public Supprimer_filiere() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		SpringLayout sl_contentPane = new SpringLayout();
		contentPane.setLayout(sl_contentPane);
		
		JLabel lblSupprimerFiliere = new JLabel("Supprimer filiere :");
		sl_contentPane.putConstraint(SpringLayout.NORTH, lblSupprimerFiliere, 27, SpringLayout.NORTH, contentPane);
		sl_contentPane.putConstraint(SpringLayout.WEST, lblSupprimerFiliere, 5, SpringLayout.WEST, contentPane);
		sl_contentPane.putConstraint(SpringLayout.EAST, lblSupprimerFiliere, 241, SpringLayout.WEST, contentPane);
		lblSupprimerFiliere.setHorizontalAlignment(SwingConstants.CENTER);
		contentPane.add(lblSupprimerFiliere);
		Connectione p=new Connectione();
		JComboBox combo = new JComboBox();
		sl_contentPane.putConstraint(SpringLayout.NORTH, combo, 19, SpringLayout.NORTH, contentPane);
		sl_contentPane.putConstraint(SpringLayout.WEST, combo, 6, SpringLayout.EAST, lblSupprimerFiliere);
		sl_contentPane.putConstraint(SpringLayout.EAST, combo, -10, SpringLayout.EAST, contentPane);
		combo.setBounds(216, 46, 114, 21);
		contentPane.add(combo);
		
		JButton btnSupprimer = new JButton("Supprimer");
		btnSupprimer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connectione p=new Connectione();
				String v=(String) combo.getItemAt(combo.getSelectedIndex());
				CharSequence c=v.subSequence(v.indexOf(":")+1, v.indexOf("/"));
				String query2;
				query2="delete from filier where codf='"+c+"'";
				try {
					
					Statement st=(Statement) p.etablirconnection().createStatement();
					st.executeUpdate(query2);
					JOptionPane.showInputDialog("supression effectuez avec succ�s");
			}
			 catch (SQLException e1) {
				
				e1.printStackTrace();
				JOptionPane.showInputDialog("error");
			}
			}
		});
		sl_contentPane.putConstraint(SpringLayout.NORTH, btnSupprimer, 39, SpringLayout.SOUTH, lblSupprimerFiliere);
		sl_contentPane.putConstraint(SpringLayout.EAST, btnSupprimer, -166, SpringLayout.EAST, contentPane);
		contentPane.add(btnSupprimer);
	    try {
	    	
			Statement st = (Statement) p.etablirconnection().createStatement();
			String query;
			query="select * from filier";
			ResultSet rt = st.executeQuery(query);
			Integer v;
			while(rt.next())
			{
				 v=rt.getRow();
				 String n=rt.getString(1);
				 int lg = n.length();
				 String nn=rt.getString(2);
				   combo.addItem(v.toString()+" code filiere :"+n+"/libelle :"+nn);
				 
			}
			}catch  (SQLException e2) {
				   JOptionPane.showMessageDialog(null, "aucune filiere  selectionner");
				
			}
	}
}