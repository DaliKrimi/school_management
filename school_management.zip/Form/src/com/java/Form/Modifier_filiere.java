package com.java.Form;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.SpringLayout;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JComboBox;

import com.mysql.jdbc.Statement;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;

public class Modifier_filiere extends JFrame {


	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private  Statement st;

	
	public Modifier_filiere() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		SpringLayout sl_contentPane = new SpringLayout();
		contentPane.setLayout(sl_contentPane);
		
		JLabel lblModifierFiliere = new JLabel("modifier filiere :");
		sl_contentPane.putConstraint(SpringLayout.NORTH, lblModifierFiliere, 47, SpringLayout.NORTH, contentPane);
		sl_contentPane.putConstraint(SpringLayout.WEST, lblModifierFiliere, 5, SpringLayout.WEST, contentPane);
		sl_contentPane.putConstraint(SpringLayout.EAST, lblModifierFiliere, 166, SpringLayout.WEST, contentPane);
		lblModifierFiliere.setHorizontalAlignment(SwingConstants.CENTER);
		contentPane.add(lblModifierFiliere);
		JComboBox combo = new JComboBox();
		combo.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				Connectione p=new Connectione();
				
				try {
					st = (Statement) p.etablirconnection().createStatement();
				} catch (SQLException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
				String v=(String) combo.getItemAt(combo.getSelectedIndex());
				 CharSequence c = v.subSequence(v.indexOf(":")+1, v.indexOf("/"));
				String query2;
				query2="select * from filier where codf='"+c+"'";
				try {
					 ResultSet rt = st.executeQuery(query2);
					if(rt.next())
					{
						textField.setText(rt.getString("codf"));
						textField_1.setText(rt.getString("libelf"));
							}
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		sl_contentPane.putConstraint(SpringLayout.NORTH, combo, -4, SpringLayout.NORTH, lblModifierFiliere);
		sl_contentPane.putConstraint(SpringLayout.WEST, combo, -228, SpringLayout.EAST, contentPane);
		sl_contentPane.putConstraint(SpringLayout.EAST, combo, -110, SpringLayout.EAST, contentPane);
		combo.setBounds(216, 46, 114, 21);
		contentPane.add(combo);
		JButton btnModifier = new JButton("modifier");
		sl_contentPane.putConstraint(SpringLayout.WEST, btnModifier, 91, SpringLayout.WEST, contentPane);
		sl_contentPane.putConstraint(SpringLayout.SOUTH, btnModifier, -77, SpringLayout.SOUTH, contentPane);
		Connectione p=new Connectione();
	    try {
		 Statement  st = (Statement) p.etablirconnection().createStatement();
			String query;
			ResultSet rt ;
			query="select * from filier";
			 rt = st.executeQuery(query);
			Integer v;
			while(rt.next())
			{	 v=rt.getRow();
				 String n=rt.getString(1);
				 int lg = n.length();
				 String nn=rt.getString(2);
				   combo.addItem(v.toString()+" codf:"+n+"/ libelle :"+nn);	 
			}	
			
			}catch  (SQLException e1) {
					   JOptionPane.showMessageDialog(null, "aucun filiere selectionner");
				}
	    
		btnModifier.addActionListener(new ActionListener() {
			@Override 
			public void actionPerformed(ActionEvent e) {
				try {
				Connectione p=new Connectione();
				String v=(String) combo.getItemAt(combo.getSelectedIndex());
				CharSequence c=v.subSequence(v.indexOf(":")+1, v.indexOf("/"));
				
				String codf =textField.getText();				
				String libelle=textField_1.getText();
				 String filiere;
				 
				String  query = "update filier set codf='"+codf+"',libelf='"+libelle+"' where codf='"+c+"'";
				st.executeUpdate(query);
				    JOptionPane.showInputDialog(this,"modification effectuez avec succ�s");
				} catch (SQLException e2) {
					e2.printStackTrace();
					JOptionPane.showInputDialog("error");
				}
			}
		}
	);
		contentPane.add(btnModifier);
		
		JLabel lblNewLabel = new JLabel("New label");
		sl_contentPane.putConstraint(SpringLayout.NORTH, lblNewLabel, 12, SpringLayout.SOUTH, lblModifierFiliere);
		sl_contentPane.putConstraint(SpringLayout.WEST, lblNewLabel, 10, SpringLayout.WEST, contentPane);
		contentPane.add(lblNewLabel);
		lblNewLabel.setText("code filier");
		JLabel lblNewLabel_1 = new JLabel("New label");
		sl_contentPane.putConstraint(SpringLayout.NORTH, lblNewLabel_1, 6, SpringLayout.SOUTH, lblNewLabel);
		sl_contentPane.putConstraint(SpringLayout.EAST, lblNewLabel_1, 0, SpringLayout.EAST, lblNewLabel);
		contentPane.add(lblNewLabel_1);
		lblNewLabel_1.setText("label filier");
		textField = new JTextField();
		sl_contentPane.putConstraint(SpringLayout.NORTH, textField, 6, SpringLayout.SOUTH, lblModifierFiliere);
		sl_contentPane.putConstraint(SpringLayout.EAST, textField, 0, SpringLayout.EAST, lblModifierFiliere);
		contentPane.add(textField);
		textField.setColumns(10);
		
		
		textField_1 = new JTextField();
		sl_contentPane.putConstraint(SpringLayout.NORTH, textField_1, 0, SpringLayout.NORTH, lblNewLabel_1);
		sl_contentPane.putConstraint(SpringLayout.EAST, textField_1, 0, SpringLayout.EAST, lblModifierFiliere);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
	}
}