package com.java.Form;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Combo;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;
import javax.swing.text.Segment;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

import com.mysql.jdbc.Statement;

import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.FocusAdapter;
import org.eclipse.swt.events.FocusEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

public class Affecter_note {

	protected Shell shell;
	private Text text;
	private Text text_1;
private java.sql.Statement st;
private ResultSet rt;
private Integer v;
private String va;
	
	/**
	 * @wbp.parser.entryPoint
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shell = new Shell();
		shell.setSize(450, 300);
		shell.setText("Ajout_note");
		
		Combo combo = new Combo(shell, SWT.NONE);
		
		combo.setBounds(218, 28, 97, 28);
		Combo combo_1 = new Combo(shell, SWT.NONE);
		combo_1.setBounds(218, 87, 97, 28);
		Connectione p=new Connectione();
	    try {
	    	
			 st =p.etablirconnection().createStatement();
			String query;
			query="select * from etudiant";
			
			 rt = st.executeQuery(query);
			
			while(rt.next())
			{
				 v=rt.getRow();
				 String n=rt.getString(1);
				
				 String nn=rt.getString(2);
				 String a=rt.getString(6);
				 
				   combo.add(v.toString()+" ref_scolaire :"+n+"/nom :"+nn+" codf ="+a);
				 
			}
			
			combo.addFocusListener(new FocusAdapter() {
				@Override
				public void focusLost(FocusEvent e) {
					 va=combo.getItem(combo.getSelectionIndex());
					 CharSequence c = va.subSequence(va.indexOf("=")+1,va.length());
					String query1="select * from matiere where codf='"+c+"' ";
					try {
						rt = st.executeQuery(query1);
						while(rt.next())
						{
							 v=rt.getRow();
							 String n=rt.getString(1);
							 
							 String nn=rt.getString(2);
							   combo_1.add(v.toString()+" codm :"+n+"/ libelm :"+nn);
							 
						}
					} catch (SQLException e1) {
						
						e1.printStackTrace();
					}
				}
			});
			

			
		
				}catch  (SQLException e2) {
					   JOptionPane.showMessageDialog(null, "aucun etudiant selectionner");
				}
		
		Label lblChoisirLetudiant = new Label(shell, SWT.NONE);
		lblChoisirLetudiant.setBounds(51, 36, 121, 20);
		lblChoisirLetudiant.setText("choisir l'etudiant");
		
		
		
		Label lblChoisirMatier = new Label(shell, SWT.NONE);
		lblChoisirMatier.setBounds(51, 95, 121, 20);
		lblChoisirMatier.setText("choisir matier");
		
		Label lblNoteDs = new Label(shell, SWT.NONE);
		lblNoteDs.setBounds(10, 133, 70, 20);
		lblNoteDs.setText("NOTE DS");
		
		text = new Text(shell, SWT.BORDER);
		text.setBounds(86, 133, 78, 26);
		
		Label lblNoteExament = new Label(shell, SWT.NONE);
		lblNoteExament.setBounds(188, 133, 113, 20);
		lblNoteExament.setText("NOTE EXAMEN");
		
		text_1 = new Text(shell, SWT.BORDER);
		text_1.setBounds(307, 130, 78, 26);
		
		Button btnAjout = new Button(shell, SWT.NONE);
		btnAjout.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				Connectione p=new Connectione();
				String ds =text.getText();
				String ex=text_1.getText();

				try {
				java.sql.Statement st = p.etablirconnection().createStatement();
				String query;
				CharSequence c = va.subSequence(va.indexOf(":")+1,va.indexOf("/"));
				String va1 = combo_1.getItem(combo_1.getSelectionIndex());
				CharSequence var = va1.subSequence(va1.indexOf(":")+1,va1.indexOf("/"));
				
				query="insert into note values('"+var+"','"+c+"','"+ds+"','"+ex+"' ) ";
				st.executeUpdate(query);
				JOptionPane.showMessageDialog(null, "ajout effectuer");
				}catch  (SQLException e2) {
					System.out.println(e2.getMessage());
					   JOptionPane.showMessageDialog(null, "Erreur a l'ajout "+e2.getMessage());
				}
				
				
				
				
				
				
				
			}
		});
		btnAjout.setBounds(153, 182, 90, 30);
		btnAjout.setText("Ajout");

	}

}
