package com.java.Form;

public class Main {
	public static void main(String[] args) {
		try {
			Acceuil win = new Acceuil();
			win.open();
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
