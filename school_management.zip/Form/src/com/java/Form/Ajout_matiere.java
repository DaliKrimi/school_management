package com.java.Form;

import java.awt.BorderLayout;
import java.awt.event.*;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.BoxLayout;

import java.awt.FlowLayout;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

//import com.jgoodies.forms.factories.DefaultComponentFactory;
import com.mysql.jdbc.Statement;

import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.SpringLayout;

import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.DropMode;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;
import javax.swing.JComboBox;

public class Ajout_matiere extends JFrame {
	
	private JPanel contentPane;
	private JTextField codm;
	private JTextField libm;
	private Connection conn;
	private Statement state ;
	
	

	public Ajout_matiere() {
		
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel lblAjoutDeMatiere = new JLabel("ajout de matiere ");
		lblAjoutDeMatiere.setHorizontalAlignment(SwingConstants.CENTER);
		lblAjoutDeMatiere.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblAjoutDeMatiere.setLabelFor(this);
		
		JLabel lblCodeMatiere = new JLabel("code matiere : ");
		lblCodeMatiere.setVerticalAlignment(SwingConstants.TOP);
		
		codm = new JTextField();
		codm.setColumns(10);
		
		JLabel lblLibelle = new JLabel("Libelle:");
		
		libm = new JTextField();
		libm.setColumns(10);
		
		JButton ajouter = new JButton("Ajouter");
		
		JComboBox combo = new JComboBox();
		
		JLabel lblNewLabel = new JLabel("filiere de matiere");
		
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(26)
							.addComponent(lblAjoutDeMatiere, GroupLayout.PREFERRED_SIZE, 424, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addContainerGap()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(lblCodeMatiere)
								.addComponent(lblLibelle))
							.addGap(18)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(libm, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(codm, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(43)
							.addComponent(ajouter)))
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
				.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 140, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED, 44, Short.MAX_VALUE)
					.addComponent(combo, GroupLayout.PREFERRED_SIZE, 114, GroupLayout.PREFERRED_SIZE)
					.addGap(152))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addComponent(lblAjoutDeMatiere)
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblCodeMatiere, GroupLayout.PREFERRED_SIZE, 32, GroupLayout.PREFERRED_SIZE)
						.addComponent(codm, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblLibelle)
						.addComponent(libm, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(combo, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 32, GroupLayout.PREFERRED_SIZE))
					.addGap(32)
					.addComponent(ajouter)
					.addContainerGap(56, Short.MAX_VALUE))
		);
		contentPane.setLayout(gl_contentPane);
		Connectione p=new Connectione();
		 try {
		    	
				Statement st = (Statement) p.etablirconnection().createStatement();
				String query;
				query="select * from filier";
				ResultSet rt = st.executeQuery(query);
				Integer v;
				while(rt.next())
				{
					 v=rt.getRow();
					 String n=rt.getString(1);
					 int lg = n.length();
					 String nn=rt.getString(2);
					   combo.addItem(v.toString()+" code filiere :"+n+"/libelle :"+nn);
					 
				}
				}catch  (SQLException e2) {
					   JOptionPane.showMessageDialog(null, "aucune filiere  selectionner");
					
				}
		ajouter.addActionListener(new ActionListener () {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				String v=(String) combo.getItemAt(combo.getSelectedIndex());
				CharSequence c=v.subSequence(v.indexOf(":")+1, v.indexOf("/"));
			String code =codm.getText();
			String lib =libm.getText();
			try {
				Connectione p=new Connectione();
				 state = (Statement) p.etablirconnection().createStatement();
				String query="insert into matiere values ('"+code+ "','"+lib+"','"+c+"')";
				state.executeUpdate(query);
				JOptionPane.showMessageDialog(null,"ajout effectuez avec succ�s");
			} catch (SQLException e1) {
				
				e1.printStackTrace();
				 JOptionPane.showMessageDialog(null, "Erreur a l'ajout");
			}
			}
		});
	}
}
