package com.java.Form;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.custom.ScrolledComposite;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.FocusAdapter;
import org.eclipse.swt.events.FocusEvent;

public class Modif_etudiant {

	protected Shell shell;
	private Text text;
	private Text text_1;
	private Text text_2;
	private Text text_3;
	private Text text_4;
	private Text text_5;
	private int lg=0;
private ResultSet rt;
private Statement st;
private CharSequence c;
	
	/**
	 * @wbp.parser.entryPoint
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shell = new Shell();
		shell.setSize(450, 300);
		shell.setText("MODIFIER_ETUDIANT");
		Combo combo = new Combo(shell, SWT.NONE);
		combo.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {

				String v=combo.getItem(combo.getSelectionIndex());
				 c=v.subSequence(v.indexOf(":")+1, v.indexOf("/"));
				String query2;
				query2="select * from etudiant where refs='"+c+"'";
				try {
					rt = st.executeQuery(query2);
					if(rt.next())
					{
						text.setText(rt.getString("nom"));
						text_1.setText(rt.getString("prenom"));
						text_2.setText(rt.getString("mail"));
						text_3.setText(rt.getString("tel"));
						String a=rt.getString("refc");
						text_5.setText(a);
						String query3="select libelf from filier where codf='"+rt.getInt("codf")+"'";
						
						ResultSet rr=st.executeQuery(query3);
						rr.first();
						
						text_4.setText(rr.getString("libelf"));
						
						
						text_5.setText(a);
					}
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				
				
			
			}
		});
		combo.setBounds(200, 7, 183, 28);
		
		Label lblEtudiantAModifier = new Label(shell, SWT.NONE);
		lblEtudiantAModifier.setBounds(10, 10, 135, 20);
		lblEtudiantAModifier.setText("etudiant a modifier");
		
		Label lblNom = new Label(shell, SWT.NONE);
		lblNom.setText("nom");
		lblNom.setBounds(20, 44, 70, 20);
		
		Label lblPrenom = new Label(shell, SWT.NONE);
		lblPrenom.setText("prenom");
		lblPrenom.setBounds(20, 70, 70, 20);
		
		Label lblMail = new Label(shell, SWT.NONE);
		lblMail.setText("mail");
		lblMail.setBounds(20, 96, 70, 20);
		
		Label lblNumtel = new Label(shell, SWT.NONE);
		lblNumtel.setText("num_tel");
		lblNumtel.setBounds(20, 122, 70, 20);
		
		Label lblFilier = new Label(shell, SWT.NONE);
		lblFilier.setText("filier");
		lblFilier.setBounds(20, 148, 70, 20);
		
		text = new Text(shell, SWT.BORDER);
		text.setBounds(106, 41, 78, 26);
		
		text_1 = new Text(shell, SWT.BORDER);
		text_1.setBounds(106, 67, 78, 26);
		
		text_2 = new Text(shell, SWT.BORDER);
		text_2.setBounds(106, 90, 123, 26);
		
		text_3 = new Text(shell, SWT.BORDER);
		text_3.setBounds(106, 116, 123, 26);
		
		text_4 = new Text(shell, SWT.BORDER);
		text_4.setBounds(106, 142, 78, 26);
		
		Label lblNumclass = new Label(shell, SWT.NONE);
		lblNumclass.setText("num_class");
		lblNumclass.setBounds(20, 174, 70, 20);
		
		text_5 = new Text(shell, SWT.BORDER);
		text_5.setBounds(106, 168, 78, 26);
		
		Button btnModifier = new Button(shell, SWT.NONE);
		Connectione p=new Connectione();
	    try {
	    	
			 st = p.etablirconnection().createStatement();
			String query;
			query="select * from etudiant";
			 rt = st.executeQuery(query);
			Integer v;
			while(rt.next())
			{
				 v=rt.getRow();
				 String n=rt.getString(1);
				 lg=n.length();
				 String nn=rt.getString(2);
				   combo.add(v.toString()+" ref_scolaire :"+n+"/nom :"+nn);
				 
			}	
		
				}catch  (SQLException e2) {
					   JOptionPane.showMessageDialog(null, "aucun etudiant selectionner");
				}
		btnModifier.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				

				Connectione p=new Connectione();
				String nom = text.getText();
				String prenom=text_1.getText();
				String email = text_2.getText();
				int tel =Integer.parseInt( text_3.getText());
				String nomf = text_4.getText();
				String nomc = text_5.getText();
				String query1="select codf from filier where libelf='"+nomf+"'";
				
				try {
				Statement st = p.etablirconnection().createStatement();
				String query;
				ResultSet rt = st.executeQuery(query1);
				int v=0;
				if(rt.next())
				{
					 v=rt.getInt("codf");
				}
				
				
				 query="update etudiant set nom='"+nom+"' ,prenom='"+prenom+"',mail='"+email+"',tel='"+tel+"',codf='"+v+"',refc='"+nomc+"' where refs='"+c+"'";
				 st.executeUpdate(query);
				    JOptionPane.showMessageDialog(null,"modification effectuez avec succ�s");
				  
				}catch  (SQLException e2) {
					   JOptionPane.showMessageDialog(null, "Erreur de modification");
				}
		
			
			
				
			}
		});
		btnModifier.setBounds(54, 200, 90, 30);
		btnModifier.setText("Modifier");

	}

}
